class Handler
    def run(req)
        return "Hello from your Ruby function. Input: #{req}"
    end
end
